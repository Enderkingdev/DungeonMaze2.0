﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{
	public float speed;
	public Text countText;
	public Text winText;
	public int PickUpObjects;
    public Transform Checkpoint;
    //public GameObject Barrier;

    private Rigidbody rb;
	private int count;
    private int levelToLoad;
	private Vector3 DefaultScale = new Vector3(1F, 1F, 1F);
	private Vector3 SmallScale = new Vector3(0.5F, 0.5F, 0.5F);
    private Scene CurrentScene;

    void Start ()
	{
        CurrentScene = SceneManager.GetActiveScene();
        rb = GetComponent<Rigidbody>();
		count = 0;
		SetCountText();
		winText.text = "";
	}
	
	void FixedUpdate()
	{
		float moveHorizontal = Input.GetAxis ("Horizontal");
		float moveVertical = Input.GetAxis ("Vertical");
		
		Vector3 movement = new Vector3 (moveHorizontal, 0.0f, moveVertical);
		
		rb.AddForce (movement * speed);
	}
	
	void OnTriggerEnter(Collider other)
	{
		if (other.gameObject.CompareTag("Pick Up"))
		{
			other.gameObject.SetActive (false);
			count++;
			SetCountText();
		} 
		else if ((other.gameObject.CompareTag("ShrinkBox")) && (GameObject.Find ("Player").transform.localScale == DefaultScale))
		{
			transform.localScale = SmallScale;
		}
		else if ((other.gameObject.CompareTag("GrowBox")) && (GameObject.Find ("Player").transform.localScale == SmallScale))
		{
			transform.localScale = DefaultScale;
		}
        else if (other.gameObject.CompareTag("Hazard"))
        {
            transform.localPosition = Checkpoint.position;
        }
    }
	
	void SetCountText()
	{
		countText.text = "Count: " + count.ToString();
		if (count >= PickUpObjects)
		{
            if (CurrentScene.buildIndex == 0)
            {
                levelToLoad = 1;
                SceneManager.LoadScene(levelToLoad);
            }
            else
            {
                winText.text = "You Win!";
            }
            //Barrier.gameObject.SetActive(false);
		}
	}
}
/* https://unity3d.college/2016/09/26/scenemanager/ */
